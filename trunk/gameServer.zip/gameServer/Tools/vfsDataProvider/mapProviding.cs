using System;
using System.Collections.Generic;
using System.IO;
using gameServer.Game.World;

namespace gameServer.Tools.vfsDataProvider {
	class mapProviding {
		public static void loadMaps() {
			List<string> maps = new List<string>();
			int createdGrids = 0;
			int createdAreas = 0;
			int createdNPCs = 0;

			foreach(string namez in vfsDataProvider.Instance.fileNames) {
				if(namez.Length < 12)
					continue;
				if(namez.Substring(0, 8) == "data\\map") {
					int mapDirID;
					string mapDirIDs = namez.Substring(8, 3);
					if(int.TryParse(mapDirIDs, out mapDirID) == true) {
						if(maps.Contains(mapDirIDs))
							continue;
						maps.Add(mapDirIDs);
						createdGrids++;
						createdAreas += loadMap(mapDirIDs);
						createdNPCs += loadNPCs(mapDirIDs);
					}
				}
			}

			Logger.WriteLog(Logger.LogTypes.Info, "Created {0} grids with {1} areas {2} npcs", createdGrids, createdAreas, createdNPCs);
		}

		public static int loadMap(string mapIdentifier) {
			vfsDataProvider.Instance.unpackFromVFS("data\\map" + mapIdentifier + "\\region" + mapIdentifier + ".bin", "data\\regions\\region" + mapIdentifier + ".bin");

			if(!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "data/regions/region" + mapIdentifier + ".bin"))
				return 0;

			int mapID = Convert.ToInt32(mapIdentifier);
			byte[] data = File.ReadAllBytes(AppDomain.CurrentDomain.BaseDirectory + "data/regions/region" + mapIdentifier + ".bin");
			int x = BitConverter.ToInt32(data, 0);
			int y = BitConverter.ToInt32(data, 4);
			int fxPos = BitConverter.ToInt32(data, 8 + x * y);
			int fyPos = BitConverter.ToInt32(data, 8 + x * y + 4);

			Grid grid = new Grid();
			grid.setgID(mapID);
			grid.setgSize(new int[] { x, y });
			grid.setaSize(256);
			grid.setStartingGridPosition(new float[] { fxPos, fyPos });
			grid.setEndingGridPosition(new float[] { fxPos + (grid.getgSize()[0] * grid.getaSize()), fyPos + (grid.getgSize()[1] * grid.getaSize()) });
			WMap.Instance.addGrid(grid);

			int position = 8;
			for(int i = 0;i < y;i++) {
				for(int u = 0;u < x;u++) {
					WMap.Instance.getGrid(mapID).getArea((u * ((x > y) ? (x) : (y))) + i).setRegionID((byte)data[position]);
					position++;
				}
			}

			return x * y;
		}

		public static int loadNPCs(string mapIdentifier) {
			vfsDataProvider.Instance.unpackFromVFS("data\\map" + mapIdentifier + "\\npc" + mapIdentifier + ".arr", "data\\npcs\\npc" + mapIdentifier + ".arr");

			if(!File.Exists(AppDomain.CurrentDomain.BaseDirectory + "data/npcs/npc" + mapIdentifier + ".arr"))
				return 0;

			int npc_counts = 0;

			int mapID = Convert.ToInt32(mapIdentifier);
			byte[] data = File.ReadAllBytes(AppDomain.CurrentDomain.BaseDirectory + "data/npcs/npc" + mapIdentifier + ".arr");

			if(data.Length < 20)
				return 0;

			int u = 0;
			int npc_data_length = 0;
			if(mapIdentifier != "207")
				npc_data_length = 28;
			else
				npc_data_length = 20;
			while(u * npc_data_length < data.Length) {
				int npcmID = BitConverter.ToInt16(data, u * npc_data_length);
				float x = BitConverter.ToSingle(data, u * npc_data_length + 4);
				float y = BitConverter.ToSingle(data, u * npc_data_length + 8);

				NPC npc = new NPC(npcmID);
				npc.setMap((short)mapID);
				npc.setPosition(new float[] { x, y });
				Area area = WMap.Instance.getGrid(mapID).getAreaByRound(x, y);

				if(area != null) {
					WMap.Instance.addToNPCs(npc);
					area.addNPC(npc);
					npc_counts++;
				}

				u++;
			}

			return npc_counts;
		}
	}
}
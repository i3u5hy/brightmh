﻿using System;
using System.Linq;
using gameServer.Core.IO;
using gameServer.Game;
using gameServer.Game.World;
using gameServer.Tools;

namespace gameServer.Packets
{
	static class StaticPackets
	{
		public static void setCharacterLevel(Character character, byte level)
		{
			OutPacket p = new OutPacket(40);
			p.WriteInt(40);
			p.WriteShort(0x05);
			p.WriteShort(0x20);
			p.WriteByte(0x01);
			p.WriteByte(0x39);
			p.WriteByte(0x07);
			p.WriteByte(0x08);
			p.WriteInt(character.getcID());
			p.WriteShort(level);
			p.WriteShort(character.getStatPoints());
			p.WriteInt(character.getSkillPoints());
			p.WriteInt(character.getMaxHP());
			p.WriteShort((short)character.getMaxMP());
			p.WriteShort(character.getMaxSP());
			character.getAccount().mClient.WriteRawPacket(p.ToArray());

			character.setLevel(level);
		}

		public static void updateStatsAttributes(Character character, short[] attributes = null, short sp = -1)
		{
			if(attributes != null) {
				character.setStr(attributes[0]);
				character.setDex(attributes[1]);
				character.setVit(attributes[2]);
				character.setInt(attributes[3]);
				character.setAgi(attributes[4]);
			}
			if(sp != -1) {
				character.setStatPoints(sp);
			}

			OutPacket p = new OutPacket(32);
			p.WriteInt(32);
			p.WriteShort(0x04);
			p.WriteShort(0x1d);
			p.WriteInt(0x01);
			p.WriteInt(character.getcID());
			p.WriteShort(0x01);
			p.WriteShort(character.getStr()); // Strength
			p.WriteShort(character.getDex()); // Dextery
			p.WriteShort(character.getVit()); // Vitality
			p.WriteShort(character.getInt()); // Intelligence
			p.WriteShort(character.getAgi()); // Agility
			p.WriteShort(character.getStatPoints()); // statusPoints
			p.WriteByte(0x40);
			p.WriteByte(0x2a);
			character.getAccount().mClient.WriteRawPacket(p.ToArray());
		}

		public static void releaseHealPacket(Character character, int hpParam = 1000, short mpParam = 1000, short spParam = 1000)
		{
			OutPacket p = new OutPacket(32);
			p.WriteInt(32);
			p.WriteShort(0x05);
			p.WriteShort(0x35);
			p.WriteByte(0x08);
			p.WriteByte(0x60);
			p.WriteByte(0x22);
			p.WriteByte(0x45);
			p.WriteInt(character.getcID());
			p.WriteInt(0x03);
			p.WriteInt();
			p.WriteInt(hpParam);
			p.WriteShort(mpParam);
			p.WriteShort(spParam);
			character.getAccount().mClient.WriteRawPacket(p.ToArray());
		}

		public static byte[] playerIsntConnected(Character character)
		{
			OutPacket p = new OutPacket(48);
			p.WriteInt(48);
			p.WriteShort(0x05);
			p.WriteShort(0x07);
			p.WriteInt(0x01);
			p.WriteInt(character.getcID());
			p.WriteZero(2);
			p.WriteShort(0x01);
			p.WriteZero(20);
			p.WriteInt(0x04);
			p.WriteByte(0x34);
			p.WriteByte(0x33);
			p.WriteByte(0x34);
			p.WriteByte(0x33);
			return p.ToArray();
		}

		public static byte[] chatRelay(Character character, byte messageType, string message)
		{
			OutPacket p = new OutPacket(message.Length + 44);
			p.WriteInt(message.Length + 44);
			p.WriteShort(0x05);
			p.WriteShort(0x07);
			p.WriteByte(0x05);
			p.WriteByte(0x01);
			p.WriteByte(0xfe);
			p.WriteByte(0x14);
			p.WriteInt(character.getcID());
			p.WriteZero(1);
			p.WriteByte(0x01);
			p.WriteShort(messageType);
			p.WritePaddedString(character.getName(), 20);
			p.WriteInt(message.Length);
			p.WriteString(message);
			return p.ToArray();
		}

		public static void setCharacterFame(Character character, int fameAmount) {
			OutPacket p = new OutPacket(192);
			p.WriteInt(192);
			p.WriteShort(0x04);
			p.WriteShort(0x64);
			p.WriteInt(1);
			p.WriteInt(character.getcID());
			p.WriteShort(0x05);
			p.WriteShort(0x05);
			p.WriteInt(0x0F);
			p.WriteInt(fameAmount);

			character.setFame(fameAmount);
			character.getAccount().mClient.WriteRawPacket(p.ToArray());
		}

		public static void sendSystemMessageToClient(MartialClient c, byte messageType, string message) {
			OutPacket p = new OutPacket(45 + message.Length);
			p.WriteInt(45 + message.Length);
			p.WriteShort(0x05);
			p.WriteShort(0x07);
			p.WriteShort(0x01);
			p.WriteZero(7);
			p.WriteByte(0x01);
			p.WriteShort(messageType);
			p.WritePaddedString("*System*", 20);
			p.WriteInt(0x3e);
			p.WriteString(message);
			c.WriteRawPacket(p.ToArray());
		}

		public static void sendWorldAnnounce(string message) {
			OutPacket p = new OutPacket(message.Length + 14);
			p.WriteInt(message.Length + 14);
			p.WriteShort(0x03);
			p.WriteByte(0x50);
			p.WriteShort(0xc3);
			p.WriteInt(message.Length);
			p.WriteString(message);

			foreach(Character chara in WMap.Instance.getWorldCharacters()) {
				chara.getAccount().mClient.WriteRawPacket(p.ToArray());
			}
		}
	}

	static class ChatPackets
	{
		public static void HandleChat(Character character, byte messageType, string message, string receiver = null)
		{
			if(messageType == 0) {
				WMap.Instance.getGrid(character.getMap()).sendTo3x3Area(character, character.getArea(), StaticPackets.chatRelay(character, messageType, message));
				return;
			}
			if(messageType == 1)
			{
				if(receiver == null)
					return;

				Character player = WMap.Instance.findPlayerByName(receiver);
				if(player == null) {
					character.getAccount().mClient.WriteRawPacket(StaticPackets.playerIsntConnected(character));
					return;
				}
				
				player.getAccount().mClient.WriteRawPacket(StaticPackets.chatRelay(character, messageType, message));
				return;
			}
			if(messageType == 9) // GM Commands
			{
				string[] cmd = System.Text.RegularExpressions.Regex.Split(message, " ");
				if(cmd[0] == "/qtest") {
					OutPacket p = new OutPacket(78);
					p.WriteBytes(new byte[] {
						(byte)0x20, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x05, (byte)0x00, (byte)0x35, (byte)0x00,
						(byte)0x08, (byte)0x20, (byte)0x9d, (byte)0x44, (byte)0x01, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x02, (byte)0x00, (byte)0x01, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0xe9, (byte)0x04, (byte)0x00, (byte)0x00, (byte)0x32, (byte)0x03, (byte)0x9f, (byte)0x01,
						(byte)0x2e, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x05, (byte)0x00, (byte)0x07, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x01, (byte)0x6e, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x02, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x32, (byte)0x34 });
					character.getAccount().mClient.WriteRawPacket(p.ToArray());
				}
				if(cmd[0] == "/setatt") {
					if(cmd.Length < 8) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/setatt [name] [str] [dex] [vit] [int] [agi] [sp]");
						return;
					}

					Character player = WMap.Instance.findPlayerByName(cmd[1]);
					if(player == null) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Wrong player name has been given.");
						return;
					}

					short[] stats = new short[5];
					for(int i = 2;i < 7;i++) {
						short strugglingStat = Convert.ToInt16(cmd[i]);
						if(strugglingStat < 0 || strugglingStat > 32767) {
							StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Maximal range of single stat is 0 - 32767.");
							return;
						}
						stats[i - 2] = strugglingStat;
					}

					short sp = Convert.ToInt16(cmd[7]);

					StaticPackets.updateStatsAttributes(player, stats, sp);
					StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "You have updated " + player.getName() + "'s stats to: ");
					StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Str: " + stats[0] + ", dex: " + stats[1] + ", vit: " + stats[2] + ", int: " + stats[3] + ", agi: " + stats[4] + "!");
				}
				if(cmd[0] == "/heal") {
					if(cmd.Length < 4) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/heal [HP] [MP] [SP]");
						return;
					}
					
					int hpParam = Convert.ToInt32(cmd[1]);
					short mpParam = Convert.ToInt16(cmd[2]);
					short spParam = Convert.ToInt16(cmd[3]);

					StaticPackets.releaseHealPacket(character, hpParam, mpParam, spParam);
				}
				if(cmd[0] == "/item") {
					if(cmd.Length < 2) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/item [itemid] [*amount]");
						return;
					}

					OutPacket p = new OutPacket(56);
					p.WriteInt(56);
					p.WriteShort(0x05);
					p.WriteInt(0x0e);
					p.WriteZero(10);
					p.WriteInt(Convert.ToInt32(cmd[1]));
					p.WriteZero(4);
					p.WriteInt();// Convert.ToInt32(cmd[2])
					p.WriteInt(character.getcID());
					p.WriteBytes(BitTools.floatToByteArray(character.getPosition()[0]));
					p.WriteBytes(BitTools.floatToByteArray(character.getPosition()[1]));
					character.getAccount().mClient.WriteRawPacket(p.ToArray());
					Console.WriteLine("item: " + BitConverter.ToString(p.ToArray()));
					return;
				}
				if(cmd[0] == "/mtest") {
					if(cmd.Length < 2) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/mtest [message]");
						return;
					}
					string messaging = string.Join(" ", cmd.Skip(1).ToArray());

					for(byte x = 0;x < 20;x++) {
						OutPacket p = new OutPacket(45 + message.Length);
						p.WriteInt(45 + message.Length);
						p.WriteShort(0x05);
						p.WriteShort(0x07);
						p.WriteShort(0x01);
						p.WriteZero(7);
						p.WriteByte(0x01);
						p.WriteShort(0);
						p.WritePaddedString("*", 20);
						p.WriteInt(x);
						p.WriteString(messaging);
						character.getAccount().mClient.WriteRawPacket(p.ToArray());
					}
					return;
				}
				if(cmd[0] == "/message") {
					if(cmd.Length < 3) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/message [type] [message]");
						return;
					}
					string messaging = string.Join(" ", cmd.Skip(2).ToArray());
					StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, Convert.ToByte(cmd[1]), messaging);
					return;
				}
				if(cmd[0] == "/announce") {
					if(cmd.Length < 2) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/announce [text]");
						return;
					}
					string announcing = string.Join(" ", cmd.Skip(1).ToArray());
					StaticPackets.sendWorldAnnounce(announcing);
					return;
				}
				if(cmd[0] == "/setlevel") {
					if(cmd.Length < 3) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/setlevel [name] [amount]");
						return;
					}

					Character player = WMap.Instance.findPlayerByName(cmd[1]);
					if(player == null) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Wrong player name has been given.");
						return;
					}

					byte level = Convert.ToByte(cmd[2]);
					if(level < 0 || level > 167) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Setlevel range goes from 0 - 167.");
						return;
					}

					StaticPackets.setCharacterLevel(player, level);
					StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, player.getName() + "'s level has been set up to: " + level + "!");
				}
				if(cmd[0] == "/setfame") {
					if(cmd.Length < 3) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/setfame [name] [amount]");
						return;
					}

					Character player = WMap.Instance.findPlayerByName(cmd[1]);
					if(player == null) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Wrong player name has been given.");
						return;
					}

					int fameAmount = Convert.ToInt32(cmd[2]);
					if(fameAmount < 0 || fameAmount > 2147483647) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "Setfame range goes from 0 - 2147483647.");
						return;
					}

					StaticPackets.setCharacterFame(player, fameAmount);
					StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, player.getName() + "'s fame has been set up to: " + fameAmount + "!");
					return;
				}
				if(cmd[0] == "/goto") {
					if(cmd.Length <= 3) {
						StaticPackets.sendSystemMessageToClient(character.getAccount().mClient, 1, "/goto [x] [y] [map]");
						return;
					}

					character.setPlayerPosition(Convert.ToSingle(cmd[1]), Convert.ToSingle(cmd[2]), Convert.ToInt16(cmd[3]));
				}
				if(cmd[0] == "/test") {
					byte[] messenger = new byte[] {
						(byte)0x63, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x01, (byte)0x00, (byte)0x14, (byte)0x00, 
						(byte)0xb9, (byte)0x78, (byte)0x05, (byte)0x00, (byte)0x32, (byte)0x30, (byte)0x31, (byte)0x34,
						(byte)0x2d, (byte)0x31, (byte)0x30, (byte)0x2d, (byte)0x31, (byte)0x38, (byte)0x20, (byte)0x32,
						(byte)0x30, (byte)0x3a, (byte)0x32, (byte)0x33, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x0c, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x04, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0xbd, (byte)0xe0, (byte)0x0f, (byte)0x00, (byte)0x7e, (byte)0xea, (byte)0x0f, (byte)0x00,
						/*receiverm*/(byte)0x32, (byte)0x31, (byte)0x31, (byte)0x33, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, /*servername*/(byte)0xb4, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
						(byte)0x00, (byte)0x00, (byte)0x20, (byte)0x08, (byte)0x0b, (byte)0x00, (byte)0x00, (byte)0x00,
						/*message*/(byte)0xbe, (byte)0xc8, (byte)0xb3, (byte)0xe7, (byte)0xc7, (byte)0xcf, (byte)0xbc, (byte)0xbc,
						(byte)0xbf, (byte)0xe4, (byte)0x00};
					string senderm = "~`BrightMH`~";
					string receiverm = "GM@Peterhausen";
					string servername = "BrightMH";
					string testing = "BrightMH!  ";
					for(int i = 0;i < senderm.Length;i++) {
						messenger[i + 56] = (byte)senderm[i];
					}
					for(int i = 0;i < receiverm.Length;i++) {
						messenger[i + 48] = (byte)receiverm[i];
					}
					for(int i = 0;i < servername.Length;i++) {
						messenger[i + 65] = (byte)servername[i];
					}
					for(int i = 0;i < testing.Length;i++) {
						messenger[i + 88] = (byte)testing[i];
					}
					character.getAccount().mClient.WriteRawPacket(messenger);
					return;
				}
				return;
			}
		}
	}
	static class MoveCharacterPacket {
		public static void HandleMovement(Account acc, byte[] tx, byte[] ty, byte mMode) {
			OutPacket p = new OutPacket(56);
			Character target = acc.activeCharacter;
			if(target == null) {
				Logger.WriteLog(Logger.LogTypes.HEmi, "Wrong target has been selected by moving packet");
				return;
			}

			Logger.WriteLog(Logger.LogTypes.Info, BitTools.byteArrayToFloat(tx) + " | " + BitTools.byteArrayToFloat(ty));

			Area lastArea = target.getArea();
			Boolean nullify = false;
			if(lastArea == null)
				nullify = true;
			Area newArea = WMap.Instance.getGrid(target.getMap()).getAreaByRound(target.getPosition()[0], target.getPosition()[1]);
			if(!nullify) {
				if(lastArea != newArea) {
					lastArea.removeCharacter(target);
					newArea.addCharacter(target);
					target.setArea(newArea);
				}
			}
			else if(nullify) {
				newArea.addCharacter(target);
				target.setArea(newArea);
			}

			p.WriteBytes(BitTools.intToByteArray(56));
			p.WriteByte(0x04);//4
			p.Skip(1);
			p.WriteByte(0x0D);//6
			p.Skip(5);//11
			p.WriteBytes(BitTools.intToByteArray(target.getcID()));
			p.WriteBytes(BitTools.floatToByteArray(target.getPosition()[0]));
			p.WriteBytes(BitTools.floatToByteArray(target.getPosition()[1]));
			//2nd set 
			p.WriteBytes(tx);
			p.WriteBytes(ty);
			p.WriteBytes(BitTools.intToByteArray(newArea.getaID()));
			p.put(36, (byte)0x80);
			p.put(37, (byte)0x3f);
			p.put(38, (byte)0x01);
			p.put(39, (byte)0x03);
			p.put(40, (byte)0x05);
			p.put(41, (byte)0x08);
			p.put(42, (byte)0x50);
			p.put(43, (byte)0x01);
			p.put(44, (byte)0x00);
			p.put(45, (byte)0x00);
			p.put(48, (byte)0x2e);
			p.put(49, (byte)0x01);
			p.put(50, (byte)0xe3);
			p.put(51, (byte)0x00);
			p.put(52, (byte)newArea.getRegionID());
			p.WriteZero(3);
			Logger.WriteLog(Logger.LogTypes.Info, newArea.getaID() + " | " + newArea.getRegionID());
			acc.mClient.WriteRawPacket(p.ToArray());

			OutPacket externalMovement = new OutPacket(48);
			externalMovement.WriteInt((int)externalMovement.Length); // 0 - 3
			externalMovement.WriteByte((byte)0x05); // 4
			externalMovement.WriteByte(); // 5
			externalMovement.WriteByte((byte)0x0D); // 6
			externalMovement.WriteByte(); // 7
			externalMovement.WriteByte((byte)0x01); // 8
			externalMovement.Skip(3);
			externalMovement.WriteInt(target.getcID());
			externalMovement.WriteFloat(target.getPosition()[0]);
			externalMovement.WriteFloat(target.getPosition()[1]);
			externalMovement.WriteBytes(tx);
			externalMovement.WriteBytes(ty);
			externalMovement.WriteByte(mMode); // who knows? | 36
			externalMovement.Skip(8);
			externalMovement.WriteByte((newArea != lastArea) ? ((byte)0x05) : ((byte)0x03));

			WMap.Instance.getGrid(target.getMap()).sendTo3x3AreaMovement(target, newArea, externalMovement.ToArray());

			if(newArea.getAreaTriggers().Count() > 0) {
				foreach(AreaTrigger areaTrigger in newArea.getAreaTriggers()) {
					if(areaTrigger.getFactionID() > 0 && target.getFaction() != areaTrigger.getFactionID())
						continue;
					if((WMap.distance(target.getPosition()[0], target.getPosition()[1], areaTrigger.getFromPosition()[0], areaTrigger.getFromPosition()[1]) < 15)) {
						try {
							target.setPlayerPosition(areaTrigger.getToPosition()[0], areaTrigger.getToPosition()[1], areaTrigger.gettMap());
						}
						catch(Exception e) {
							Console.WriteLine(e);
						}
					}
					if(WMap.distance(target.getPosition()[0], target.getPosition()[1], areaTrigger.getToPosition()[0], areaTrigger.getToPosition()[1]) < 15) {
						try {
							target.setPlayerPosition(areaTrigger.getFromPosition()[0], areaTrigger.getFromPosition()[1], areaTrigger.getfMap());
						}
						catch(Exception e) {
							Console.WriteLine(e);
						}
					}
				}
			}
			target.setPosition(new float[] { (float)BitTools.byteArrayToFloat(tx), (float)BitTools.byteArrayToFloat(ty) });
		}
	}

	static class LoginPacketCreator
	{
		public static byte[] initCharacters(Account acc, bool backSpawn = false) {
			OutPacket all = new OutPacket((acc.characters.Count() * 653) + 8 + 3);
			byte[] size = BitTools.shortToByteArray(Convert.ToInt16((acc.characters.Count() * 653) + 8 + 3));
			all.WriteBytes(size);
			all.WriteBytes(new byte[] { (byte)0x00, (byte)0x00, (byte)0x03, (byte)0x00, (!backSpawn) ? ((byte)0x04) : ((byte)0x01), (byte)0x00, (byte)0x01, (byte)0x01, (byte)0x01 });

			int multipier_keeper = all.ToArray()[10];
			Boolean multiplied = false;

			foreach(Character chara in acc.characters) {
				all.WriteBytes(chara.initCharPacket());

				if(multiplied)
					multipier_keeper = (multipier_keeper * 2) + 1;
				if(!multiplied)
					multiplied = true;
			}

			all.put(10, (byte)multipier_keeper);
			return all.ToArray();
		}
	}
}
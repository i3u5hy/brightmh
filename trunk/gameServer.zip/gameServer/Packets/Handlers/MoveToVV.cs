﻿using gameServer.Core.IO;
using gameServer.Game;
using gameServer.Tools;

namespace gameServer.Packets.Handlers {
	class MoveToVV {
		public static void _buffie(MartialClient c, InPacket p) {
			Logger.WriteLog(Logger.LogTypes.HEmi, "Move to VV validate");

			if(c.getAccount().activeCharacter != null)
				return;

			int selected_character = p.ReadByte()-1;

			if(c.getAccount().characters[selected_character] == null) {
				Logger.WriteLog(Logger.LogTypes.HEmi, "Wrong target has been selected by packet");
				return;
			}

			Character target = c.getAccount().characters[selected_character];

			target.setPosition(new float[] { -1660, 2344 });
			target.setMap(1);

			OutPacket op = new OutPacket(24);
			op.WriteInt(24);
			op.WriteShort(0x03);
			op.WriteShort(0x0e);
			op.WriteByte(0x01);
			op.WriteByte((byte)selected_character);
			op.WriteByte(0x06);
			op.WriteByte(0x08);
			op.WriteByte(1); // map
			op.WriteZero(4);
			op.WriteByte(0x80); // X
			op.WriteByte(0xcf); //
			op.WriteByte(0xc4); //
			op.WriteZero(1);
			op.WriteByte(0x80); // Y
			op.WriteByte(0x12); //
			op.WriteByte(0x45); //
			c.WriteRawPacket(op.ToArray());
		}
	}
}

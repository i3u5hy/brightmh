﻿using gameServer.Core.IO;

namespace gameServer.Packets.Handlers {
	class Equip {
		public static void _buffie(MartialClient c, InPacket p) {
			OutPacket op = new OutPacket(24);
			op.WriteInt(24);
			op.WriteShort(0x04);
			op.WriteShort(0x0c);
			op.WriteByte(0x01);
			op.WriteByte(0xff);
			op.WriteByte(0x14);
			op.WriteByte(0x08);
			op.WriteInt(c.getAccount().activeCharacter.getcID());
			op.WriteShort(0x01);
			op.WriteByte(0x01);

			p.Skip(5);

			op.WriteByte(p.ReadByte());
			op.WriteByte(p.ReadByte());
			c.WriteRawPacket(op.ToArray());
		}
	}
}

﻿using System.Linq;
using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers {
	class RefreshArea {
		public static void _buffie2(MartialClient c, InPacket p) {
			c.WriteRawPacket(new byte[] {(byte)0x09, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x02, (byte)0x00, (byte)0x36, (byte)0x00, (byte)0xf6, (byte)0x09, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x02, (byte)0x00, (byte)0x41, (byte)0x00, (byte)0xf6, (byte)0x09, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x02, (byte)0x00, (byte)0x70, (byte)0x00, (byte)0xec, (byte)0x10, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x02, (byte)0x00, (byte)0x06, (byte)0x00, (byte)0x80, (byte)0x4b, (byte)0x7d, (byte)0xce, (byte)0x83, (byte)0x11, (byte)0xf7, (byte)0x59});
		}

		public static void _buffie(MartialClient c, InPacket p) {
			Logger.WriteLog(Logger.LogTypes.HEmi, "Refresh Area validate");
			byte[] op = new byte[24];
			op[0] = (byte)0x18;
			op[4] = (byte)0x04;
			op[6] = (byte)0x2f;
			op[8] = (byte)0x01;
			byte[] cid = BitTools.intToByteArray(c.getAccount().activeCharacter.getcID());
			for(int i = 0;i<4;i++) {
				op[12+i] = cid[i];
			}
			op[16] = (byte)0x01;
			op[23] = (byte)0x2a;
			c.WriteRawPacket(op.ToArray());

		}
	}
}

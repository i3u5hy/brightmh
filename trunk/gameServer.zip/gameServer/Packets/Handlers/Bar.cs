﻿using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers {
	static class Bar {
		public static void _buffie(MartialClient c, InPacket p) {
			Logger.WriteLog(Logger.LogTypes.HEmi, "Bar validate");

			p.Skip(8);
			byte[] decrypted = p.ReadBytes(16);
			byte[] booth = new byte[24];

			byte[] chid = BitTools.intToByteArray(c.getAccount().activeCharacter.getcID());

			booth[0] = (byte)booth.Length;
			booth[4] = (byte)0x04;
			booth[6] = (byte)0x11;
			booth[8] = (byte)0x01;
			booth[9] = (byte)0x06;
			booth[10] = (byte)0x15;
			booth[11] = (byte)0x08;

			for(int i = 0;i < 4;i++) {
				booth[12 + i] = chid[i];
			}
			booth[16] = (byte)0x01;
			booth[18] = (byte)0x01;
			booth[19] = (byte)0x01;

			booth[18] = decrypted[0];
			booth[19] = decrypted[1];
			booth[20] = decrypted[4];
			booth[21] = decrypted[5];
			booth[22] = decrypted[6];
			booth[23] = decrypted[7];
			c.WriteRawPacket(booth);
		}
	}
}
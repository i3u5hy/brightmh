﻿using gameServer.Core.IO;

namespace gameServer.Packets.Handlers {
	static class ReturnToSelection {
		public static void _buffie(MartialClient c, InPacket p) {
			if(c.getAccount().activeCharacter != null) {
				c.WriteRawPacket(LoginPacketCreator.initCharacters(c.getAccount(), true));
				c.getAccount().activeCharacter = null;
			} else Packets.Handlers.Quit._buffie(c, null);
		}
	}
}

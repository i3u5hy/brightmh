﻿using gameServer.Core.IO;

namespace gameServer.Packets.Handlers {
	class Pickup {
		public static void _buffie(MartialClient c, InPacket p) {
			OutPacket ops = new OutPacket(20);
			ops.WriteInt(20);
			ops.WriteShort(0x05);
			ops.WriteShort(0x0f);
			ops.WriteInt(0x01);
			ops.WriteInt();

			p.Skip(4);

			int itemID = 241221001; // items have uid

			System.Console.WriteLine("ItemID: " + itemID);

			ops.WriteInt(p.ReadByte());

			//

			OutPacket op = new OutPacket(40);
			op.WriteInt(40);
			op.WriteShort(0x05);
			op.WriteShort(0x0f);
			op.WriteByte(0x01);
			op.WriteByte(0x9c);
			op.WriteByte(0x04);
			op.WriteByte(0x08);
			op.WriteInt(c.getAccount().activeCharacter.getcID());
			op.WriteShort(0x01);
			op.WriteByte(0xcf);
			op.WriteByte(0x2d);
			op.WriteByte(0x03);
			op.WriteZero(3);
			op.WriteByte(p.ReadByte());

			byte[] decryptedDoubling = p.ReadBytes(2);

			op.WriteByte(decryptedDoubling[0]);
			op.WriteByte(decryptedDoubling[1]);
			op.WriteZero(1);
			op.WriteByte(1);
			op.WriteZero(1);
			op.WriteByte(decryptedDoubling[0]);
			op.WriteByte(decryptedDoubling[1]);
			op.WriteInt(itemID);
			op.WriteByte(0x01);

			//System.Console.WriteLine("op: " + System.BitConverter.ToString(op.ToArray()));
			//System.Console.WriteLine("ops: " + System.BitConverter.ToString(ops.ToArray()));

			c.WriteRawPacket(ops.ToArray());
			c.WriteRawPacket(op.ToArray());
		}
	}
}

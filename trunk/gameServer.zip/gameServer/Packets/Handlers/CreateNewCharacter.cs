﻿using System;
using System.Text;
using gameServer.Core.IO;
using gameServer.Game;
using gameServer.Servers;
using gameServer.Tools;

namespace gameServer.Packets.Handlers
{
	static class CreateNewCharacter
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			Logger.WriteLog(Logger.LogTypes.HEmi, "CreateNewCharacter handle");

			Console.WriteLine("create char packet: {0}", BitConverter.ToString(p.ToArray()));
			
			Character newChr = new Character();

			p.Skip(4);

			newChr.setClient(c);
			byte[] charBName = p.ReadBytes(16);
			for (int i = 0; i < 16; i++)
			{
				if (charBName[i] != 0x00) continue;
				Array.Resize(ref charBName, i);
				break;
			}

			newChr.setName(Encoding.ASCII.GetString(charBName));

			if (MasterServer.Instance.SqlConnection.NameTaken(newChr.getName()) || charBName[0] == 0x00)
			{
				Logger.WriteLog(Logger.LogTypes.HEmi, "Player name has been already taken: {0}", newChr.getName());
				c.WriteRawPacket(Constants.createNCharNameTaken);
				return;
			}

			p.Skip(2);
			newChr.setFace(p.ReadByte());

			p.Skip(5);
			newChr.setcClass(p.ReadByte());

			p.Skip(1);
			newChr.setStr(p.ReadByte());

			p.Skip(1);
			newChr.setDex(p.ReadByte());

			p.Skip(1);
			newChr.setVit(p.ReadByte());

			p.Skip(1);
			newChr.setAgi(p.ReadByte());

			p.Skip(1);
			newChr.setInt(p.ReadByte());

			p.Skip(1);
			newChr.setStatPoints(p.ReadByte());

			newChr.setFaction(0);
			newChr.setLevel(1);
			newChr.setMaxHP(50);
			newChr.setCurHP(50);
			newChr.setMaxMP(50);
			newChr.setCurMP(50);
			newChr.setMaxSP(50);
			newChr.setCurSP(50);
			newChr.setAtk(50);
			newChr.setDef(50);
			newChr.setCoin(0);
			newChr.setFame(0);
			newChr.setPosition(new float[] {-1660, 2344});
			newChr.setMap(1);
			newChr.setSkillPoints(0);
			newChr.setAccount(c.getAccount());

			if (newChr.Create() == 1)
			{
				newChr.setcID(MasterServer.Instance.SqlConnection.GetLastInsertId());
				//MySQLTool.CreateInventories(newChr);
				//MySQLTool.CreateEquips(newChr, equips);
				//MySQLTool.LoadInventoriesId(newChr);
				c.getAccount().appendToCharacters(newChr);
				c.WriteRawPacket(Constants.createNewCharacter);
				return;
			}

			c.WriteRawPacket(Constants.createNCharNameTaken);

			//Logger.LogCheat(Logger.HackTypes.Login, c, "Attempted to create a character that already exists.");
			//c.Close();
			return;
		}
	}
}

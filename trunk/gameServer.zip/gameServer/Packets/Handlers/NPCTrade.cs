﻿using System.Linq;
using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers {
	public class NPCTrade {
		public static void _buffie(MartialClient c, InPacket p) {
			p.Skip(4);

			OutPacket op = new OutPacket(56);
			op.WriteInt(56);
			op.WriteShort(0x04);
			op.WriteShort(0x13);
			op.WriteInt(0x01);
			op.WriteInt(c.getAccount().activeCharacter.getcID());
			op.WriteByte(0x47);
			op.WriteByte(0x76);
			op.WriteInt(p.ReadByte());
			op.WriteShort();
			op.WriteInt(0x01);
			op.WriteByte();
			op.WriteByte(0x47);
			op.WriteShort();
			op.WriteByte(0x4b);
			op.WriteByte(0x6b);
			op.WriteInt();
			op.WriteByte(0x80);
			op.WriteByte(0x3f);
			op.WriteShort();
			op.WriteByte(0x80);
			op.WriteByte(0x3f);

			c.WriteRawPacket(op.ToArray());
		}
	}
}

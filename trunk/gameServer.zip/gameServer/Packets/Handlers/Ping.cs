﻿using gameServer.Core.IO;

namespace gameServer.Packets.Handlers
{
	static class Ping
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			c.WriteRawPacket(new byte[0]);
		}
	}
}
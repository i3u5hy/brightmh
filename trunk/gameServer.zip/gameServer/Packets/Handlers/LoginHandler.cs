﻿using System.Linq;
using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers
{
	static class LoginHandler
	{
		public static void _buffie(MartialClient c, InPacket p) {
			Logger.WriteLog(Logger.LogTypes.HEmi, "Handle validate");
			c.getAccount().LoadCharacters();
			if(c.getAccount().characters.Count() > 0) {
				c.WriteRawPacket(LoginPacketCreator.initCharacters(c.getAccount(), false).Concat(Constants.emptyAccount).ToArray());
			}
			c.WriteRawPacket(Constants.emptyAccount);
			c.WriteRawPacket(new byte[] { (byte)0x34, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x03, (byte)0x00, (byte)0x05, (byte)0x00, (byte)0x50, (byte)0x65, (byte)0x6a, (byte)0x64, (byte)0x6a, (byte)0x36, (byte)0x38, (byte)0x38,
				(byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
				(byte)0x6d, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x00,
				(byte)c.getAccount().characters.Count(), (byte)0x00, (byte)0x00, (byte)0x00 }); // amount of characters (yellow information)
		}

		public static void LauncherValidate(MartialClient c, InPacket p)
		{
			Logger.WriteLog(Logger.LogTypes.HEmi, "Launcher");
			c.setSessionID(Randomizer.Generate());
			_buffie(c, p);
		}

		/*public static void HandleLogin(MartialClient c, InPacket p)
		{
			/*string pass = p.ReadMartialString();
			string user = p.ReadMartialString().Replace("NP12:auth06:5:0:", "");

			Logger.WriteLog(Logger.LogTypes.Info, "Someone logged in with {0} and {1}.", user, pass);
			//TODO: Login check.
			c.Account.Id = 1;
			c.Account.Username = "admin";
			c.Account.Password = "admin";
			c.Account.Load();

			c.WritePacket(LoginPacketCreator.LoginSuccess(c.Account, c.SessionID));
			c.Account.LoggedIn = 1;
			c.Account.Characters = new List<Character>();
		}

		public static void HandleCheckUserLimit(MartialClient c, InPacket p)
		{
			byte world = p.ReadByte();

			if (!MasterServer.Instance.Worlds.InRange(world))
			{
				return;
			}

			int current = MasterServer.Instance.Worlds[world].CurrentLoad;

			if (current >= Constants.MaxPlayers) //full
			{
				c.WritePacket(LoginPacketCreator.CheckUserLimit(2));
			}
			else if (current * 2 >= Constants.MaxPlayers) //half full
			{
				c.WritePacket(LoginPacketCreator.CheckUserLimit(1));
			}
			else //under half full
			{
				c.WritePacket(LoginPacketCreator.CheckUserLimit(0));
			}
		}*/
	}
}

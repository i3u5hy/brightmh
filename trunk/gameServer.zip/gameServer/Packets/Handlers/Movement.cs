﻿using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers
{
	class Movement
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			Logger.WriteLog(Logger.LogTypes.HEmi, "OnPlayerMove validate");
			p.Skip(8);
			byte[] locationToX = p.ReadBytes(4);
			byte[] locationToY = p.ReadBytes(4);
			p.Skip(1);
			byte movingMode = p.ReadByte();
			MoveCharacterPacket.HandleMovement(c.getAccount(), locationToX, locationToY, movingMode);
		}
	}
}

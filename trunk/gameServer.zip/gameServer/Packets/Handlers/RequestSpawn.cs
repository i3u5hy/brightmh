﻿using gameServer.Core.IO;
using gameServer.Game;
using gameServer.Game.World;
using gameServer.Tools;

namespace gameServer.Packets.Handlers
{
	class RequestSpawn
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			if (c.getAccount().activeCharacter != null)
				return;

			int selected_character = p.ReadByte()-1;

			if(c.getAccount().characters[selected_character] == null) {
				Logger.WriteLog(Logger.LogTypes.HEmi, "Wrong target has been selected by packet");
				return;
			}

			Character target = c.getAccount().characters[selected_character];

			c.getAccount().activeCharacter = target;

			WMap.Instance.addToCharacters(target);
			target.setPlayerPosition(target.getPosition()[0], target.getPosition()[1], target.getMap());
			StaticPackets.sendSystemMessageToClient(c, 1, Constants.WelcomeMessage);
		}
	}
}
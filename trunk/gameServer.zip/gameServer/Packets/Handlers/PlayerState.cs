﻿using gameServer.Core.IO;
using gameServer.Tools;

namespace gameServer.Packets.Handlers {
	static class PlayerState {
		public static void _buffie(MartialClient c, InPacket p) {
			Logger.WriteLog(Logger.LogTypes.HEmi, "Emoticons validate");
			p.Skip(4);
			byte[] decrypted = p.ReadBytes(4);
			byte[] emoticon = new byte[24];

			byte[] chid = BitTools.intToByteArray(c.getAccount().activeCharacter.getcID());

			emoticon[0] = (byte)0x18;
			emoticon[4] = (byte)0x05;
			emoticon[6] = (byte)0x06;
			emoticon[8] = (byte)0x01;
			for(int i = 0;i < 4;i++) {
				emoticon[12 + i] = chid[i];
			}
			emoticon[16] = decrypted[0];
			emoticon[18] = decrypted[2];
			emoticon[19] = decrypted[3];
			c.WriteRawPacket(emoticon);
		}
	}
}

﻿using gameServer.Core.IO;

namespace gameServer.Packets.Handlers
{
	class Quit
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			c.WriteRawPacket(new byte[] { (byte)0x09, (byte)0x00, (byte)0x00, (byte)0x00, (byte)0x03, (byte)0x00, (byte)0x64, (byte)0x00, (byte)0x00 });
			c.Close();
		}
	}
}

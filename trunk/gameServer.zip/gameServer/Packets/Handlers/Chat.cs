﻿using gameServer.Core.IO;
using gameServer.Game;

namespace gameServer.Packets.Handlers
{
	class Chat
	{
		public static void _buffie(MartialClient c, InPacket p)
		{
			if (c.getAccount().activeCharacter == null) return;
			Character target = c.getAccount().activeCharacter;
			p.Skip(4);
			byte messageType = (byte)p.ReadShort();
			string receiver = p.ReadString(17).Replace("\0", "");
			byte messageLength = (byte)p.ReadInt();
			string message = p.ReadString(messageLength);

			ChatPackets.HandleChat(target, messageType, message, receiver);
		}
	}
}

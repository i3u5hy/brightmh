﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Timers;
using gameServer.Servers;
using gameServer.Tools;

namespace gameServer
{
	class main
	{
		static void Main(string[] args)
		{
			Console.ForegroundColor = ConsoleColor.White;
			Timer titleUpdate = new Timer();
			titleUpdate.Interval = 15000;
			titleUpdate.Elapsed += titleUpdate_Elapsed;
			titleUpdate.Start();
			UpdateTitle();

			if(!Constants.initialiseConfig()) {
				Console.WriteLine("It seems, that you're running BMH emulator for the first time.");
				Console.WriteLine("Close this server now, and configure config.ini");
				Console.ReadKey();
				Environment.Exit(0);
			}

			MasterServer.Instance = new MasterServer();

			Logger.WriteHeader();
			Logger.WriteLog(Logger.LogTypes.Info, "BrightMH.gameServer - v" + "0" + "." + "1" + " started.");
			MasterServer.Instance.Run();
			Logger.mCommandEnabled = true;
			Console.Write("> ");

			while (true)
			{
				ConsoleKeyInfo key = Console.ReadKey(true);
				char chr = key.KeyChar;
				if (key.Key == ConsoleKey.Backspace)
				{
					if (Logger.mCommandBuffer.Length > 0)
					{
						Logger.mCommandBuffer = Logger.mCommandBuffer.Remove(Logger.mCommandBuffer.Length - 1);
					}
					Console.CursorLeft = 0;
					var ret = String.Format("> {0}  ", Logger.mCommandBuffer);
					Console.Write(ret);
					Console.CursorLeft = ret.Length - 2;
				}
				else if (key.Key != ConsoleKey.Enter)
				{
					Logger.mCommandBuffer += key.KeyChar;
					Console.Write(key.KeyChar);
				}
				else
				{
					if(Logger.mCommandBuffer.Length == 0)
						continue;
					Console.WriteLine();
					string[] cmd = Regex.Split(Logger.mCommandBuffer, " ");

					switch (cmd[0])
					{
						case "register":
							if (cmd.Length == 1)
							{
								Logger.WriteLog(Logger.LogTypes.Info, "register name pass uniqid");
								break;
							}
							//MasterServer.Instance.Database.RegisterAccount(cmd[1], cmd[2], cmd[3], true);
							Logger.WriteLog(Logger.LogTypes.Info, "Account {0} created.", cmd[1]);
							break;
						case "message":
							break;
						case "help":
							Logger.WriteLog(Logger.LogTypes.Info, "Available commands: Register.");
							break;
						case "npc":
                            gameServer.Game.Character character = MySQLTool.GetCharacter(1);
                            character.setArea(Game.World.WMap.Instance.getGrid(1).getAreaByRound(character.getPosition()[0], character.getPosition()[1]));
                            Random random = new Random();
                            int randomize = random.Next(gameServer.Game.World.WMap.Instance.getNpcs().Count());
                            gameServer.Game.World.NPC npc = gameServer.Game.World.WMap.Instance.getNpcs()[randomize];
                            Console.WriteLine(BitConverter.ToString(npc.npcSpawn(character)));
                            Console.WriteLine("spawn packet for {0}", npc.getuID());
                            break;
						case "test":
							string file = File.ReadAllText("test");
							byte[] array = hexStringToByteArray(file);
							MasterServer.Instance.HellEmissary.SendBytes(array);
							break;
						default:
							Logger.WriteLog(Logger.LogTypes.Info, "Command does not exist. For a list, type help.");
							break;
					}

					Logger.mCommandBuffer = Logger.mCommandBuffer.Remove(Logger.mCommandBuffer.Length - 1);
				}
			}
		}

		public static byte[] hexStringToByteArray(String s) {
			byte[] b = new byte[s.Length / 2];
			for(int i = 0;i < b.Length;i++) {
				int index = i * 2;
				int v = Convert.ToInt32(s.Substring(index, 2), 16);
				b[i] = (byte)v;
			}
			return b;
		}

		public static int GetHexVal(char hex) {
			int val = (int)hex;
			return val - (val < 58 ? 48 : 55);
		}

		private static void titleUpdate_Elapsed(object sender, ElapsedEventArgs e)
		{
			UpdateTitle();
		}

		static void UpdateTitle()
		{
			GC.Collect();
			Console.Title = "BrightMH - C# Martial Heroes Emulator | Memory Usage: " + Math.Round((double)GC.GetTotalMemory(false) / 1024) + "KB";
		}
	}
}

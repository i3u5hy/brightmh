﻿using System;
using System.Collections.Generic;
using gameServer.Core.IO;
using gameServer.Tools;
using gameServer.Game.Objects;

namespace gameServer.Game.World
{
	public sealed class NPC
	{
		private int uID, mID;
		private short map;
		private float[] npcPosition;
		private NPCData npcData;

		public NPC(int mID = 0)
		{
			uID = WMap.Instance.getNpcs().Count+1;
			this.mID = mID;
		}

		public int getuID() {
			return this.uID;
		}

		public byte[] npcSpawn(Character character)
		{
			OutPacket initNPCData = new OutPacket(615);
			initNPCData.WriteInt(615);
			initNPCData.put(4, (byte)0x04);
            initNPCData.put(6, (byte)0x04);
            initNPCData.put(8, (byte)0x01);
            initNPCData.put(9, BitTools.intToByteArray((int)character.getcID()));
            initNPCData.put(13, BitTools.intToByteArray((int)character.getArea().getaID()));
            initNPCData.put(17, BitTools.floatToByteArray(character.getPosition()[0]));
            initNPCData.put(21, BitTools.floatToByteArray(character.getPosition()[1]));
            initNPCData.put(25, (byte)0x03); // 25
            initNPCData.put(26, BitTools.intToByteArray((int)this.uID)); // 26 - 29
            initNPCData.put(34, this.getName(), 16); // 34 - 49
			initNPCData.put(68, (byte)this.getModule()); // 68
            initNPCData.put(82, BitTools.intToByteArray((int)this.getmID())); // 82 - 85
            initNPCData.put(102, BitTools.floatToByteArray(this.getPosition()[0]));
            initNPCData.put(106, BitTools.floatToByteArray(this.getPosition()[1]));
			initNPCData.put(612, (byte)0x22);
            initNPCData.put(613, (byte)0x08);
            initNPCData.WriteByte();
            Console.WriteLine((int)character.getcID() + " | " + (int)character.getArea().getaID() + " | " + character.getPosition()[0] +
                " | " + character.getPosition()[1] + " | " + this.uID + " | " + this.getmID() + " | " + this.getPosition()[0] + " | " + this.getPosition()[1]);
			return initNPCData.ToArray();
		}

		public int getmID() {
			return this.mID;
		}

		public int getModule() {
			return this.npcData.getModule();
		}

		public void setModule(byte module) {
			this.npcData.setModule(module);
		}

		public short getMap()
		{
			return map;
		}

		public void setMap(short map)
		{
			this.map = map;
		}

		public float[] getPosition()
		{
			return this.npcPosition;
		}

		public void setPosition(float[] position)
		{
			this.npcPosition = position;
		}

		public String getName()
		{
			return npcData.getName();
		}

		public void setNPCDataStreaming(NPCData npcData)
		{
			this.npcData = npcData;
		}
	}
}
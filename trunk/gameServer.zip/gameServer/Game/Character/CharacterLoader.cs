﻿using System;
using System.Collections.Generic;
using gameServer.Servers;
using MySql.Data.MySqlClient;

namespace gameServer.Game.Objects
{
    public class CharacterLoader
    {
		public Boolean loadEq(Dictionary<byte, Item> equipment, int charID) {
			MasterServer.Instance.SqlConnection.RunQuery("SELECT * FROM chars_eq WHERE charID=" + charID);
			MySqlDataReader reader = MasterServer.Instance.SqlConnection.Reader;

			if(!reader.HasRows) {
				reader.Close();
				return false;
			}
			else {
				while(reader.Read()) {
					Item item = new Item();
					byte slot = reader.GetByte("slot");
					item.setItemID(reader.GetInt32("itemID"));
					item.setQuantity(reader.GetInt16("quantity"));
					item.setExpiration(reader.GetInt64("expiration"));
					equipment.Add(slot, item);
					Console.WriteLine("Slot {0}, item {1}", slot, item.getItemID());
				}

				reader.Close();
				return true;
			}
		}
    }
}

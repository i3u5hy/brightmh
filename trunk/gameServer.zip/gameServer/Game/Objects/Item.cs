﻿
namespace gameServer.Game.Objects {
	public class Item {
		private int itemID;
		private short quantity;
		private long expiration;

		public Item(int itemID = 0, short quantity = 1, long expiration = 0) {
			this.itemID = itemID;
			this.quantity = quantity;
			this.expiration = expiration;
		}

		public void setItemID(int itemID) {
			this.itemID = itemID;
		}

		public int getItemID() {
			return this.itemID;
		}

		public void setQuantity(short quantity) {
			this.quantity = quantity;
		}

		public short getQuantity() {
			return this.quantity;
		}

		public void setExpiration(long expiration) {
			this.expiration = expiration;
		}

		public long getExpiration() {
			return this.expiration;
		}
	}
}

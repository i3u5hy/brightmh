﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gameServer.Game.Objects {
	public sealed class NPCData
	{
		private int mID;
		private byte module;
		private string name = "null";
		private Dictionary<byte, int> tradeItems = new Dictionary<byte, int>();

		public NPCData(int mID) {
			this.mID = mID;
		}

		public int getmID() {
			return this.mID;
		}

		public void setmID(int mID) {
			this.mID = mID;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public void addToItems(byte slot, int itemID) {
			this.tradeItems.Add(slot, itemID);
		}

		public void setItems(Dictionary<byte, int> tradeItems) {
			if(tradeItems.Count == 0)
				return;
			this.tradeItems = tradeItems;
		}

		public int getModule() {
			return module;
		}

		public void setModule(byte module) {
			this.module = module;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using gameServer.Core.IO;
using gameServer.Game.Objects;
using gameServer.Game.World;
using gameServer.Servers;
using gameServer.Tools;
using MySql.Data.MySqlClient;

namespace gameServer.Game
{
	public sealed class Character
	{
		//public Dictionary<InventoryType, Inventory> Inventory { get; private set; }

		private MartialClient client;

		private int cID;
		private Account account;
		private String name;
		private short str, dex, vit, inte, agi, map, statPoints, skillPoints, vp;
		private long coin, exp;
		private int fame, maxHP, curHP, atk, def;
		private short maxMP, maxSP, curMP, curSP;
		private float[] position;
		private byte level = 1, faction = 0, face = 1, cClass = 1;
		private Boolean deleteState, vending, trading;
		private Area area;
		private List<int> innitedAreas = new List<int>();
		private Dictionary<byte, Item> equipment = new Dictionary<byte, Item>();

		public Character() { }

		public int Create()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("(charName, charClass, face, faction, level, curHP, curMP, curSP, atk, def, coin, fame, locX, locY, map, Inte, Agi, Vit, Str, Dex, statPointz, skillPointz, ownerID) ");
			sb.Append("VALUES (");
			sb.Append("'" + this.name + "',");
			sb.Append(this.cClass + ",");
			sb.Append(this.face + ",");
			sb.Append(this.faction + ",");
			sb.Append(this.level + ",");
			sb.Append(this.curHP + ",");
			sb.Append(this.curMP + ",");
			sb.Append(this.curSP + ",");
			sb.Append(this.atk + ",");
			sb.Append(this.def + ",");
			sb.Append(this.coin + ",");
			sb.Append(this.fame + ",");
			sb.Append(this.position[0] + ",");
			sb.Append(this.position[1] + ",");
			sb.Append(this.map + ",");
			sb.Append(this.inte + ",");
			sb.Append(this.agi + ",");
			sb.Append(this.vit + ",");
			sb.Append(this.str + ",");
			sb.Append(this.dex + ",");
			sb.Append(this.statPoints + ",");
			sb.Append(this.skillPoints + ",");
			sb.Append(this.account.aID);
			sb.Append(")");
			return MySQLTool.Create("chars", sb);
		}

		public int Load()
		{
			MasterServer.Instance.SqlConnection.RunQuery("SELECT * FROM chars WHERE charID = " + cID);
			MySqlDataReader reader = MasterServer.Instance.SqlConnection.Reader;
			reader.Read();

			if (!reader.HasRows)
			{
				reader.Close();
				return 0;
			}
			else
			{
				name = reader.GetString("charName");
				cClass = reader.GetByte("charClass");
				face = reader.GetByte("face");
				faction = reader.GetByte("faction");
				level = reader.GetByte("level");
				curHP = reader.GetInt32("curHP");
				curMP = reader.GetInt16("curMP");
				curSP = reader.GetInt16("curSP");
				atk = reader.GetInt16("atk");
				def = reader.GetInt16("def");
				coin = reader.GetInt64("coin");
				fame = reader.GetInt32("fame");
				setPosition(new float[] { reader.GetFloat("locX"), reader.GetFloat("locY") });
				map = reader.GetInt16("map");
				inte = reader.GetInt16("Inte");
				agi = reader.GetInt16("Agi");
				vit = reader.GetInt16("Vit");
				str = reader.GetInt16("Str");
				dex = reader.GetInt16("Dex");
				statPoints = reader.GetInt16("statPointz");
				skillPoints = reader.GetInt16("skillPointz");
				reader.Close();

				CharacterLoader charLoader = new CharacterLoader();
				charLoader.loadEq(this.equipment, this.cID);
				reader.Close();
			}
			return 1;
		}

		public byte[] vanCharPacket() {
			using (OutPacket vanCharData = new OutPacket(20)) {
				vanCharData.WriteInt((int)vanCharData.Length);
				vanCharData.WriteInt((byte)0x05);
				vanCharData.WriteByte((byte)0x01);
				vanCharData.WriteByte((byte)0x10);
				vanCharData.WriteByte((byte)0xa0);
				vanCharData.WriteByte((byte)0x36);
				vanCharData.WriteInt(this.cID);
				vanCharData.WriteByte();
				vanCharData.WriteByte((byte)0xee);
				vanCharData.WriteByte((byte)0x5f);
				vanCharData.WriteByte((byte)0xbf);
				return vanCharData.ToArray();
			}
		}

		public byte[] initCharPacket() {
			byte[] cdata = new byte[653];

			byte[] charname = Encoding.ASCII.GetBytes(this.name);
			for(int i = 0;i < this.name.Length;i++) {
				cdata[i] = charname[i];
			}

			for(int i = 0;i < 16;i++) {
				cdata[i + 17] = (byte)0x30;
			}

			cdata[34] = (byte)this.faction;	//faction

			byte[] fame = BitTools.intToByteArray(this.fame);
			for(int i = 0;i < fame.Length;i++) {
				cdata[36 + i] = fame[i];
			}

			if(this.cClass == 2) cdata[40] = 0x02;
			else cdata[40] = 0x01; //male(obviously duh)

			cdata[48] = (byte)this.cClass; //class byte
			
			cdata[42] = (byte)this.face;
			cdata[54] = (byte)this.level;

			//cdata[460] = (byte)ch.getKao();		//kao
			//cdata[462] = (byte)ch.getSize();		//size
			//cdata[464] = (byte)ch.getFameTitle();	//fame title
			if(this.getAccount().gmLvl > 0) cdata[466] = (byte)0x01;

			//0 int, 1 agi, 2 vit, 3 dex, 4 str | int, vit, agi, str, dex
			for(int i = 0;i < this.getCStats().Length;i++) {
				byte[] tmp = BitTools.shortToByteArray(this.getCStats()[i]);
				cdata[576 + (i * 2)] = tmp[0];
				cdata[576 + (i * 2) + 1] = tmp[1];
			}

			byte[] statp = BitTools.intToByteArray(this.statPoints);
			byte[] skillp = BitTools.intToByteArray(this.skillPoints);

			for(int i = 0;i < 2;i++) {
				cdata[604 + i] = statp[i];
				cdata[606 + i] = skillp[i];
			}

			cdata[44] = (byte)0x01; //standard its 01 but 00 gives no errors, no explanation yet
			cdata[52] = (byte)0x02; //standard its 02 but 00 goes as well nothing changes though, no explanation yet

			byte[] stuff = new byte[] { (byte)0x00, (byte)0xa0, (byte)0x01, (byte)0x00, (byte)0x00, (byte)0x7c, (byte)0x01, (byte)0x00,							   
				(byte)0x00, (byte)0x01, (byte)0x00, (byte)0x00, (byte)0x00, 
				(byte)0xf3, (byte)0xd4, (byte)0x13, (byte)0xc5, (byte)0x9a, 
				(byte)0xb9, (byte)0xbd, (byte)0xc5, (byte)0x00, (byte)0x00, 
				(byte)0x02, (byte)0x00 };

			for(int i = 0;i < stuff.Length;i++) {
				cdata[i + 66 - 8 - 3] = stuff[i];
			}

			byte[] bytes;
			byte[] amount;
			// equipment
			for(byte i = 0;i < 17;i++) {
				if(this.equipment.ContainsKey(i)) {
					bytes = BitTools.intToByteArray(this.equipment[i].getItemID());
					amount = BitTools.intToByteArray(this.equipment[i].getQuantity());
					for(int j = 0;j < 4;j++) {
						cdata[80 + i * 12 + j] = bytes[j];
						cdata[84 + i * 12 + j] = amount[j];
					}
				}
			}

			//coords
			byte[] bx = BitTools.floatToByteArray(this.position[0]);
			byte[] by = BitTools.floatToByteArray(this.position[1]);

			for(int i = 0;i < 4;i++) {
				cdata[68 + i] = bx[i];
				cdata[72 + i] = by[i];
			}

			cdata[465] = (byte)this.vp;

			//abandoned in char selection
			//if(ch.isAbandoned()) cdata[648] = (byte)0x01;

			return cdata;
		}

		public short[] getCStats() {
			return new short[] { this.inte, this.agi, this.vit, this.dex, this.str };
		}

		public byte[] extCharPacket() {
			byte[] cedata = new byte[612];
			short length = (short)cedata.Length;
			byte[] lengthbytes = BitTools.shortToByteArray(length);
			byte[] chID = BitTools.intToByteArray(this.cID);
			byte[] chName = System.Text.Encoding.ASCII.GetBytes(this.name);
			byte[] xCoords = BitTools.floatToByteArray(this.position[0]);
			byte[] yCoords = BitTools.floatToByteArray(this.position[1]);

			cedata[0] = lengthbytes[0];
			cedata[1] = lengthbytes[1];
			cedata[4] = (byte)0x05;
			cedata[6] = (byte)0x01;
			cedata[8] = (byte)0x01;

			for(int i = 0;i < 4;i++) {
				cedata[i + 12] = chID[i]; //character ID
				cedata[i + 88] = xCoords[i]; //location x
				cedata[i + 92] = yCoords[i]; //location y
			}

			for(int i = 0;i < chName.Length;i++) {
				cedata[i + 20] = chName[i]; //characters Name
			}

			for(int i = 0;i < 16;i++) {
				cedata[37 + i] = (byte)0x30; //character packets have 16 times 30(0 in ASCII) in row. Mysteries of CRS.
			}

			if(this.cClass == 2) {
				cedata[60] = (byte)0x02; //gender byte
				cedata[68] = (byte)0x02; //class byte
			}
			else {
				cedata[60] = (byte)0x01; //gender byte
				cedata[68] = (byte)this.cClass; //class byte
			}


			return cedata;
		}

		public void setPlayerPosition(float goX, float goY, short map) {
			MartialClient c = this.getAccount().mClient;

			Logger.WriteLog(Logger.LogTypes.Debug, goX + " | " + goY + " | " + map);
		
			Area lastArea = this.getArea();
			Area newArea = WMap.Instance.getGrid(map).getAreaByRound(goX, goY);

			if(lastArea != null) {
				WMap.Instance.getGrid(this.getMap()).sendTo3x3AreaLeave(this, lastArea);
				lastArea.removeCharacter(this);
			}

			if(newArea != null)
				this.setArea(newArea);
			else
				this.getAccount().mClient.Close();

			newArea.addCharacter(this);

			this.setMap(map);
			this.setPosition(new float[] {goX, goY});

			byte[] chID = BitTools.intToByteArray(this.cID);
			byte[] chX = BitTools.floatToByteArray(this.position[0]);
			byte[] chY = BitTools.floatToByteArray(this.position[1]);
			byte[] coins = BitTools.longToByteArray(this.coin);
			byte[] cdata = new byte[5824];
			byte[] cdatalength = BitTools.intToByteArray(cdata.Length);

			cdata[4] = (byte)0x04;
			cdata[6] = (byte)0x01;
			cdata[8] = (byte)0x01;

			for(int i = 0;i < 4;i++) {
				cdata[i] = cdatalength[i];
				cdata[12 + i] = chID[i];
			}

			cdata[20] = (byte)this.map;
			//TIME
			cdata[24] = (byte)Convert.ToByte(DateTime.Now.Year-2000);
			cdata[28] = (byte)DateTime.Now.Month;
			cdata[29] = (byte)DateTime.Now.Day;
			cdata[30] = (byte)DateTime.Now.Hour;

			for(int i = 0;i < 8;i++) {
				cdata[5128 + i] = coins[i];
			}

			for(int i = 0;i < 4;i++) {
				cdata[5800 + i] = chX[i];
				cdata[5804 + i] = chY[i];
			}

			//0c is safe zone
			//08 is nonsafe zone
			cdata[5808] = (byte)0x0c;

			cdata[5813] = (byte)0x9d;
			cdata[5814] = (byte)0x0f;
			cdata[5815] = (byte)0xbf;

			cdata[5822] = (byte)0x50;
			cdata[5823] = (byte)0x2e;

			c.WriteRawPacket(cdata);

			WMap.Instance.getGrid(c.getAccount().activeCharacter.getMap()).sendTo3x3AreaSpawn(c.getAccount().activeCharacter, c.getAccount().activeCharacter.getArea());
		}

		public void Save()
		{
			//StringBuilder sb = new StringBuilder();
			/*sb.Append("accountid = " + AccountId);
			sb.Append(", world = " + WorldId);
			sb.Append(", name = '" + Name + "'");
			sb.Append(", level = " + level);
			sb.Append(", exp = " + EXP);
			sb.Append(", str = " + Str);
			sb.Append(", dex = " + Dex);
			sb.Append(", `int` = " + Int);
			sb.Append(", luk = " + Luk);
			sb.Append(", hp = " + HP);
			sb.Append(", maxhp = " + MaxHP);
			sb.Append(", mp = " + MP);
			sb.Append(", maxmp = " + MaxMP);
			sb.Append(", meso = " + Meso);
			sb.Append(", hpApUsed = " + ApHp);
			sb.Append(", job = " + Job);
			sb.Append(", gender = " + Gender);
			sb.Append(", fame = " + Fame);
			sb.Append(", hair = " + HairId);
			sb.Append(", face = " + FaceId);
			sb.Append(", faceMarking = " + FaceMarking);
			sb.Append(", ap = " + AP);
			sb.Append(", map = " + MapId);
			sb.Append(", spawnpoint = " + SpawnPoint);
			sb.Append(", party = 0"); // TODO: Party.
			sb.Append(", buddyslots = 20"); // TODO: Buddylist.
			sb.Append(", guildid = 0"); // TODO: Guild.
			sb.Append(", guildrank = 0");
			sb.Append(", alliancerank = 0"); // TODO: Alliance.*/
			//MySQLTool.Save("chars", sb, "id", this.cID);
		}

		public void Delete()
		{
			MasterServer.Instance.SqlConnection.RunQuery("DELETE FROM chars WHERE id = " + this.cID);
		}

		public int getcID() {
			return cID;
		}

		public void setcID(int cID) {
			this.cID = cID;
		}

		public Account getAccount() {
			return account;
		}

		public void setAccount(Account account) {
			this.account = account;
		}

		public String getName() {
			return name;
		}

		public void setName(String charName) {
			this.name = charName;
		}

		public byte getcClass() {
			return cClass;
		}

		public void setcClass(byte charClass) {
			this.cClass = charClass;
		}

		public byte getFace() {
			return face;
		}

		public void setFace(byte face) {
			this.face = face;
		}

		public byte getFaction() {
			return faction;
		}

		public void setFaction(byte faction) {
			this.faction = faction;
		}

		public byte getLevel() {
			return level;
		}

		public void setLevel(byte level) {
			this.level = level;
		}

		public int getMaxHP() {
			return maxHP;
		}

		public void setMaxHP(int maxHP) {
			this.maxHP = maxHP;
		}

		public int getCurHP() {
			return curHP;
		}

		public void setCurHP(int curHP) {
			this.curHP = curHP;
		}

		public int getMaxMP() {
			return maxMP;
		}

		public void setMaxMP(short maxMP) {
			this.maxMP = maxMP;
		}

		public short getCurMP() {
			return curMP;
		}

		public void setCurMP(short curMP) {
			this.curMP = curMP;
		}

		public short getMaxSP() {
			return maxSP;
		}

		public void setMaxSP(short maxSP) {
			this.maxSP = maxSP;
		}

		public short getCurSP() {
			return curSP;
		}

		public void setCurSP(short curSP) {
			this.curSP = curSP;
		}

		public int getAtk() {
			return atk;
		}

		public void setAtk(int atk) {
			this.atk = atk;
		}

		public int getDef() {
			return def;
		}

		public void setDef(int def) {
			this.def = def;
		}

		public long getCoin() {
			return coin;
		}

		public void setCoin(long coin) {
			this.coin = coin;
		}

		public int getFame() {
			return fame;
		}

		public void setFame(int fame) {
			this.fame = fame;
		}

		public float[] getPosition() {
			return this.position;
		}

		public void setPosition(float[] position) {
			this.position = position;
		}

		public short getMap() {
			return map;
		}

		public void setMap(short map) {
			this.map = map;
		}

		public short getInt() {
			return inte;
		}

		public void setInt(short inte) {
			this.inte = inte;
		}

		public short getAgi() {
			return agi;
		}

		public void setAgi(short agi) {
			this.agi = agi;
		}

		public short getVit() {
			return vit;
		}

		public void setVit(short vit) {
			this.vit = vit;
		}

		public short getDex() {
			return dex;
		}

		public void setDex(short dex) {
			this.dex = dex;
		}

		public short getStr() {
			return str;
		}

		public void setStr(short str) {
			this.str = str;
		}

		public short getStatPoints() {
			return statPoints;
		}

		public void setStatPoints(short statPoints) {
			this.statPoints = statPoints;
		}

		public short getSkillPoints() {
			return skillPoints;
		}

		public void setSkillPoints(short skillPoints) {
			this.skillPoints = skillPoints;
		}

		public short getVp() {
			return vp;
		}

		public void setVp(short vp) {
			this.vp = vp;
		}

		/*public Inventory getInventory() {
			return inventory;
		}

		public void setInventory(Inventory inventory) {
			this.inventory = inventory;
		}

		public Cargo getCargo() {
			return cargo;
		}

		public void setCargo(Cargo cargo) {
			this.cargo = cargo;
		}

		public Equipment getEquipment() {
			return equipment;
		}

		public void setEquipment(Equipment equipment) {
			this.equipment = equipment;
		}*/

		public long getExp() {
			return exp;
		}

		public void setExp(long exp) {
			this.exp = exp;
		}

		public Boolean getDeleteState() {
			return deleteState;
		}

		public void setDeleteState(Boolean deleteState) {
			this.deleteState = deleteState;
		}

		public Area getArea() {
			return area;
		}

		public void setArea(Area area) {
			this.area = area;
		}

		public List<int> getInnitedAreas()
		{
			return innitedAreas;
		}

		public void setInnitedAreas(List<int> innitedAreas)
		{
			this.innitedAreas = innitedAreas;
		}

		public void addInnitedArea(int areaID)
		{
			this.innitedAreas.Add(areaID);
		}

		public Boolean removeInnitedArea(int innitedArea)
		{
			if (!this.innitedAreas.Contains(innitedArea)) return false;
			return this.innitedAreas.Remove(innitedArea);
		}

		public void removeInnitedAreas()
		{
			this.innitedAreas.Clear();
		}

		public MartialClient getClient() {
			return client;
		}

		public void setClient(MartialClient client) {
			this.client = client;
		}

		public void setEquipment(Dictionary<byte, Item> equipment) {
			this.equipment = equipment;
		}

		public Dictionary<byte, Item> getEquipment() {
			return this.equipment;
		}
	}
}

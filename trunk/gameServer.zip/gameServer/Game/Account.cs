﻿using System;
using System.Collections.Generic;
using System.Linq;
using gameServer.Servers;
using gameServer.Tools;
using MySql.Data.MySqlClient;

namespace gameServer.Game
{
	public sealed class Account
	{
		public MartialClient mClient { get; set; }
		public int aID { get; set; }
		public String name { get; set; }
		public int gmLvl { get; set; }
		public string ip { get; set; }
		public Character activeCharacter { get; set; }
		public List<Character> characters { get; set; }

		public Boolean Load()
		{
			this.characters = new List<Character>();

			MasterServer.Instance.SqlConnection.RunQuery("SELECT * FROM users WHERE ip='" + this.ip + "'");
			MySqlDataReader reader = MasterServer.Instance.SqlConnection.Reader;
			reader.Read();

			if (!reader.HasRows)
			{
				reader.Close();
				return false;
			}
			else
			{
				aID = reader.GetInt32("uid");
				gmLvl = reader.GetInt32("lvl");
				name = reader.GetString("username");

				reader.Close();
				return true;
			}
		}

		public void LoadCharacters()
		{
			MasterServer.Instance.SqlConnection.RunQuery("SELECT * FROM chars WHERE ownerID = " + aID + " LIMIT 5");
			MySqlDataReader reader = MasterServer.Instance.SqlConnection.Reader;
			List<int> ids = new List<int>();

			for (int i = 0; i < 5; i++)
			{
				if (!reader.Read())
					break;

				ids.Add(reader.GetInt32(0));
			}

			foreach (int id in ids)
            {
                Character chr = new Character();
                chr.setcID(id);

                if (chr.Load() == 0)
                    Logger.WriteLog(Logger.LogTypes.Error, "Could not load character with ID {0}.", chr.getcID());

				chr.setAccount(this);
				this.appendToCharacters(chr);
			}

			reader.Close();
		}

		public void Save()
		{
			//TODO
		}

		public void appendToCharacters(Character character) {
			if(this.characters.Count() >= 5) return;
			reloadCharactersList();
			characters.Add(character);
		}

		public void reloadCharactersList() {
			List<Character> _temporary = new List<Character>();
			foreach(Character _char in characters) {
				_temporary.Add(_char);
			}
			this.characters = _temporary;
		}

		public void clearCharacters() {
			characters.Clear();
		}
	}
}

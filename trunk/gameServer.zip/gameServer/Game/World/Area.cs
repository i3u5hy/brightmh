﻿using System;
using System.Collections.Generic;

namespace gameServer.Game.World
{
	public class Area
	{
		private int aID;
		private int[] areaPosition;
		private Grid grid;
		private byte regionID;
		private List<AreaTrigger> areaTriggers = new List<AreaTrigger>();
		private List<Character> areaCharacters = new List<Character>();
		private List<NPC> npcs = new List<NPC>();

		public Area()
		{

		}

		public void sendAreaInit(Character character) {
			MartialClient connection = character.getAccount().mClient;
            if (character.getInnitedAreas().Contains(this.aID)) return;
			foreach(Character aCharacter in areaCharacters) {
				if(aCharacter == character) continue;
				try {
					connection.WriteRawPacket(aCharacter.extCharPacket());
				} catch(Exception e) { Console.WriteLine(e); }
			}
			foreach (NPC aNPC in npcs) {
				try {
					connection.WriteRawPacket(aNPC.npcSpawn(character));
				} catch (Exception e) { Console.WriteLine(e); }
			}
		}

		public int getaID()
		{
			return this.aID;
		}

		public void setaID(int aID)
		{
			this.aID = aID;
		}

		public int[] getAreaPosition()
		{
			return this.areaPosition;
		}

		public void setAreaPosition(int[] areaPosition)
		{
			this.areaPosition = areaPosition;
		}

		public Grid getGrid()
		{
			return this.grid;
		}

		public void setGrid(Grid grid)
		{
			this.grid = grid;
		}

		public List<AreaTrigger> getAreaTriggers()
		{
			return this.areaTriggers;
		}

		public void setAreaTriggers(List<AreaTrigger> areaTriggers)
		{
			this.areaTriggers = areaTriggers;
		}

		public void addAreaTrigger(AreaTrigger areaTrigger)
		{
			this.areaTriggers.Add(areaTrigger);
		}

		public List<NPC> getNpcs()
		{
			return npcs;
		}

		public void setNpcs(List<NPC> npcs)
		{
			this.npcs = npcs;
		}

		public void addNPC(NPC npc)
		{
			if (this.npcs.Contains(npc)) return;
			this.npcs.Add(npc);
		}

		public byte getRegionID()
		{
			return this.regionID;
		}

		public void setRegionID(byte regionID)
		{
			this.regionID = regionID;
		}

		public List<Character> getCharacters()
		{
			return this.areaCharacters;
		}

		public void setCharacters(List<Character> characters)
		{
			this.areaCharacters = characters;
		}

		public void addCharacter(Character character)
		{
			if (this.areaCharacters.Contains(character)) return;
			this.areaCharacters.Add(character);
		}

		public void removeCharacter(Character character)
		{
			if (this.areaCharacters.Contains(character)) this.areaCharacters.Remove(character);
		}
	}
}

﻿using System;
using System.IO;
using gameServer.Tools;

namespace gameServer.Servers
{
	class MasterServer
	{
		public static MasterServer Instance { get; set; }

		public bool Running { get; private set; }

		public HellEmissary HellEmissary { get; private set; }
		public ConnectionDispatcher ConnectionDispatcher { get; private set; }
		public LobbyListener LobbyListener { get; private set; }
		public MySQL_Connection SqlConnection { get; set; }

		public MasterServer()
		{
			SqlConnection = new MySQL_Connection(Constants.username, Constants.password, Constants.database, Constants.host);
			if(File.Exists("dbDump.sql")) {
				string query = File.ReadAllText("dbDump.sql");
				SqlConnection.RunQuery(query);
			}

			HellEmissary = new HellEmissary((Int16)Constants.HellPort);
			ConnectionDispatcher = new ConnectionDispatcher((Int16)Constants.CDPPort);
			LobbyListener = new LobbyListener((Int16)Constants.LLPort);
		}

		public void Run()
		{
			DateTime start = DateTime.Now;
			//Provider.Cache();
			DateTime finish = DateTime.Now;

			HellEmissary.Run();
			ConnectionDispatcher.Run();
			LobbyListener.Run();

			Running = true;

			Logger.WriteLog(Logger.LogTypes.Debug, "External IP address: {0}", Constants.ExternalIP);
			Logger.WriteLog(Logger.LogTypes.Debug, "Router IP address:   {0}", Constants.RouterIP);
		}

		public void Shutdown()
		{
			Console.WriteLine("Shutting down MasterServer");

			if(LobbyListener != null) LobbyListener.Shutdown();
			if(ConnectionDispatcher != null) ConnectionDispatcher.Shutdown();
			if(HellEmissary != null) HellEmissary.Shutdown();

			Running = false;

			Console.WriteLine("gameServer went offline.");
		}
	}
}

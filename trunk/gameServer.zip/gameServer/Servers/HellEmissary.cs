﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using gameServer.Core.Network;
using gameServer.Game;
using gameServer.Packets;
using gameServer.Tools;
using gameServer.Tools.vfsDataProvider;

namespace gameServer.Servers
{
	class HellEmissary
	{
		private Acceptor m_acceptor;
		private List<MartialClient> m_clients;
		private PacketProcessor m_processor;

		public HellEmissary(short port)
		{
			m_acceptor = new Acceptor(port);
			m_acceptor.OnClientAccepted = OnClientAccepted;

			m_clients = new List<MartialClient>();

			SpawnHandlers();
		}

		public void SendBytes(byte[] packet) {
			foreach (MartialClient mc in m_clients) {
				mc.WriteRawPacket(packet);
			}
		}

		private void SpawnHandlers()
		{
			m_processor = new PacketProcessor("MainProcessor");

			m_processor.AppendHandler(1,	Packets.Handlers.Ping._buffie);
			m_processor.AppendHandler(666,	Packets.Handlers.Quit._buffie);
			m_processor.AppendHandler(670,	Packets.Handlers.LoginHandler._buffie);
			m_processor.AppendHandler(672,	Packets.Handlers.CreateNewCharacter._buffie);
			m_processor.AppendHandler(675,	Packets.Handlers.RequestSpawn._buffie);
			m_processor.AppendHandler(680,	Packets.Handlers.MoveToVV._buffie);
			m_processor.AppendHandler(1332, Packets.Handlers.ReturnToSelection._buffie);
			//m_processor.AppendHandler(1338, Packets.Handlers.PlayerState._buffie);
			m_processor.AppendHandler(1339, Packets.Handlers.Chat._buffie);
			m_processor.AppendHandler(1344, Packets.Handlers.Equip._buffie);
			m_processor.AppendHandler(1345, Packets.Handlers.Movement._buffie);
			m_processor.AppendHandler(1347, Packets.Handlers.Pickup._buffie);
			//m_processor.AppendHandler(1349, Packets.Handlers.Bar._buffie);
			m_processor.AppendHandler(1351, Packets.Handlers.NPCTrade._buffie);
			m_processor.AppendHandler(1379,	Packets.Handlers.RefreshArea._buffie);
		}

		private void InitialiseWorld()
		{
			if(!vfsDataProvider.Instance.initVFSloader()) {
				Console.WriteLine("VFS Providing, couldn't be initialised!");
				Environment.Exit(0);
			}

			mapProviding.loadMaps();
			npcProviding.loadNPCs();
		}
		
		private void OnClientAccepted(Socket client)
		{
			MartialClient mc = new MartialClient(client, m_processor, m_clients.Remove);
			m_clients.Add(mc);
			Account account = new Account();
			account.ip = mc.Label;
			account.mClient = mc;
			mc.setAccount(account);

			if(mc.getAccount().Load()) {
				mc.WriteRawPacket(Constants.authSuccess);
				Logger.WriteLog(Logger.LogTypes.HEmi, "Client {0} connected to Hell Emissary.", mc.Label);
			}
			else {
				Logger.WriteLog(Logger.LogTypes.HEmi, "Client {0} failed to connect to HE", mc.Label);
				mc.WriteRawPacket(Constants.authFail);
				mc.Close();
				return;
			}
		}

		public void Run()
		{
			InitialiseWorld();

			m_acceptor.Start();
			Logger.WriteLog(Logger.LogTypes.Info, "HellEmissary		- {0}.", m_acceptor.Port);
		}

		public void Shutdown()
		{
			m_acceptor.Stop();
			foreach (MartialClient mc in m_clients)
				mc.Close();

			//m_clients.Clear();
		}
	}
}